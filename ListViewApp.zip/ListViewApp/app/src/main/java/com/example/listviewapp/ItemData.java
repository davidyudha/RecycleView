package com.example.listviewapp;

public class ItemData {
    public String itemTitle;
    public String itemSubtitle;
}
